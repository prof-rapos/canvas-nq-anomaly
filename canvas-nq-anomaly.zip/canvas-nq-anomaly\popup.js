const btn    = document.getElementById('runBtn');
const status = document.getElementById('status');

btn.addEventListener('click', async () => {
  btn.disabled = true;
  btn.textContent = '⏳ Running…';
  status.className = '';
  status.textContent = 'Detecting session… (the page will briefly refresh)';

  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab) throw new Error('No active tab found.');

    const resp = await chrome.runtime.sendMessage({ type: 'run', tabId: tab.id });

    if (resp && resp.error) {
      status.className = 'err';
      status.textContent = '❌ ' + resp.error;
    } else {
      status.className = 'ok';
      status.textContent = '✓ Running — check the Moderate page.';
      // Close the popup after a short delay so it doesn't sit there
      setTimeout(() => window.close(), 1400);
    }
  } catch (e) {
    status.className = 'err';
    status.textContent = '❌ ' + e.message;
  } finally {
    btn.disabled = false;
    btn.textContent = '🔍 Run Anomaly Check';
  }
});
