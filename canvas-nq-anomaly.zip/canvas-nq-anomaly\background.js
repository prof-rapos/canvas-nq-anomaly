let attachedTargetId = null;

function sendCmd(debuggee, method, params) {
  return new Promise((resolve, reject) => {
    chrome.debugger.sendCommand(debuggee, method, params || {}, result => {
      if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
      else resolve(result || {});
    });
  });
}

async function runAnalysis(tabId) {
  // Matches any quiz-lti region (yul, iad, syd, …) — avoids hardcoding the AWS region
  const LTI_HOST_RE = /quiz-lti-[a-z0-9]+-prod\.instructure\.com/;

  // The quiz LTI tool runs as an out-of-process iframe (OOPIF) — a separate CDP
  // target from the main Canvas tab. Runtime.enable on the tab only sees
  // same-process frames, which is why the LTI context never appeared there.
  // chrome.debugger.getTargets() lists ALL targets, including OOPIFs.
  const allTargets = await new Promise(r => chrome.debugger.getTargets(r));
  const httpsTargets = allTargets.filter(t => t.url && t.url.startsWith('https://'));
  console.log('[NQ bg] https targets:', httpsTargets.map(t =>
    `[${t.type}] ${t.url.slice(0, 120)}`
  ));

  // Must start with https:// to skip blob: worker targets that share the same hostname
  const ltiTarget = httpsTargets.find(t => LTI_HOST_RE.test(t.url));
  if (!ltiTarget) {
    const found = httpsTargets.map(t => t.url.slice(0, 100)).join('\n  ');
    throw new Error(
      'Quiz LTI frame not found. Make sure the Moderate page is fully loaded ' +
      'before clicking Run.\n\nTargets visible to extension:\n  ' + (found || '(none)')
    );
  }

  console.log('[NQ bg] found LTI target:', ltiTarget.id, ltiTarget.url.slice(0, 80));

  // Detach from any previous LTI target (different quiz opened, etc.)
  if (attachedTargetId && attachedTargetId !== ltiTarget.id) {
    try { await chrome.debugger.detach({ targetId: attachedTargetId }); } catch (_) {}
    attachedTargetId = null;
  }

  // Attach to the LTI iframe target
  try {
    await chrome.debugger.attach({ targetId: ltiTarget.id }, '1.3');
  } catch (e) {
    if (!e.message.includes('already attached')) throw e;
  }
  attachedTargetId = ltiTarget.id;

  // Fetch and run the anomaly-check script.
  // Evaluating via { targetId } automatically runs in that frame's main world —
  // no contextId lookup needed.
  // userGesture:true allows window.open() inside the sandboxed iframe (for PDF).
  const code = await fetch(chrome.runtime.getURL('quiz_anomaly_check.js'))
    .then(r => r.text());

  await sendCmd({ targetId: ltiTarget.id }, 'Runtime.evaluate', {
    expression: `(function(){${code}\n__nqRun();})()`,
    awaitPromise: false,
    userGesture: true,
  });

  // Debugger stays attached so window.open() keeps working when the user
  // clicks "Print PDF" later (same effect as leaving DevTools open).
}

// ── Message handler (called by popup.js) ─────────────────────────────────────
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg.type !== 'run') return false;
  runAnalysis(msg.tabId)
    .then(() => sendResponse({ ok: true }))
    .catch(e => sendResponse({ error: e.message }));
  return true;
});

// ── Cleanup when Chrome forcibly detaches us ─────────────────────────────────
chrome.debugger.onDetach.addListener((source, reason) => {
  if (source.targetId === attachedTargetId) {
    console.log('[NQ bg] LTI target detached:', reason);
    attachedTargetId = null;
  }
});
