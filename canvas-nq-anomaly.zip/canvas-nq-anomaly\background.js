let attachedTabId = null;

function sendCmd(debuggee, method, params) {
  return new Promise((resolve, reject) => {
    chrome.debugger.sendCommand(debuggee, method, params || {}, result => {
      if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
      else resolve(result || {});
    });
  });
}

function waitFor(condFn, timeoutMs) {
  return new Promise(resolve => {
    const deadline = Date.now() + timeoutMs;
    (function check() {
      if (condFn()) { resolve(true); return; }
      if (Date.now() >= deadline) { resolve(false); return; }
      setTimeout(check, 250);
    })();
  });
}

function getHeader(headers, name) {
  const key = Object.keys(headers).find(k => k.toLowerCase() === name);
  return key ? headers[key] : null;
}

// Matches any region (yul, iad, syd, …) — avoids hardcoding the AWS region
const LTI_HOST_RE = /quiz-lti-[a-z0-9]+-prod\.instructure\.com/;
const API_HOST_RE = /quiz-api-[a-z0-9]+-prod\.instructure\.com/;

// The New Quizzes moderation SDK now renders inline in the main Canvas page and
// calls quiz-lti/quiz-api directly via CORS — there's no separate LTI iframe to
// attach to anymore, and its auth tokens aren't reachable via a simple React fiber
// walk. So instead we attach to the tab itself and sniff the real credentials off
// its own network traffic on a forced reload: quiz-lti + quiz-api auth (roster),
// plus the app's own POST /api/native/launch call (params + signature), which is
// what the page itself uses to mint a fresh, one-time-use launch_token. Replaying
// that same POST later — once per student, right before fetching their log — mints
// a brand-new valid token each time (confirmed live: two replays return different
// jti/iat/signature). No per-student UI interaction needed.
async function captureAuth(tabId) {
  const debuggee = { tabId };

  try {
    await chrome.debugger.attach(debuggee, '1.3');
  } catch (e) {
    if (!e.message.includes('already attached')) throw e;
  }
  attachedTabId = tabId;

  await sendCmd(debuggee, 'Network.enable');

  const captured = { lti: null, api: null, nativeLaunch: null };

  function onEvent(source, method, params) {
    if (source.tabId !== tabId || method !== 'Network.requestWillBeSent') return;
    const url = params.request.url;
    const headers = params.request.headers || {};

    if (!captured.lti && LTI_HOST_RE.test(url)) {
      const auth = getHeader(headers, 'authorization');
      if (auth) {
        captured.lti = {
          host: new URL(url).origin,
          authorization: auth,
          xDomain: getHeader(headers, 'x-domain'),
        };
        console.log('[NQ bg] captured quiz-lti auth from', captured.lti.host);
      }
    }
    if (!captured.api && API_HOST_RE.test(url)) {
      const auth = getHeader(headers, 'authorization');
      if (auth) {
        captured.api = {
          host: new URL(url).origin,
          authorization: auth,
          authtype: getHeader(headers, 'authtype') || 'Signature',
        };
        console.log('[NQ bg] captured quiz-api auth from', captured.api.host);
      }
    }
    if (!captured.nativeLaunch && params.request.method === 'POST' &&
        LTI_HOST_RE.test(url) && /\/api\/native\/launch$/.test(url)) {
      const auth = getHeader(headers, 'authorization');
      if (auth && params.request.postData) {
        captured.nativeLaunch = {
          host: new URL(url).origin,
          authorization: auth,
          xDomain: getHeader(headers, 'x-domain'),
          body: params.request.postData,
        };
        console.log('[NQ bg] captured native/launch payload');
      }
    }
  }
  chrome.debugger.onEvent.addListener(onEvent);

  try {
    // Reload so the roster/quiz_sessions/native-launch requests all fire fresh while we're listening.
    await new Promise(resolve => chrome.tabs.reload(tabId, {}, resolve));
    await waitFor(() => captured.lti && captured.api && captured.nativeLaunch, 20000);
  } finally {
    chrome.debugger.onEvent.removeListener(onEvent);
    try { await sendCmd(debuggee, 'Network.disable'); } catch (_) {}
  }

  const missing = [];
  if (!captured.lti) missing.push('quiz-lti auth (roster)');
  if (!captured.api) missing.push('quiz-api auth (sessions)');
  if (!captured.nativeLaunch) missing.push('native/launch payload (session log token minting)');
  if (missing.length) {
    throw new Error(
      'Could not capture: ' + missing.join(', ') + '. ' +
      'Make sure the Moderate page fully loads the student list before clicking Run, then try again.'
    );
  }

  return captured;
}

async function runAnalysis(tabId) {
  const auth = await captureAuth(tabId);

  const code = await fetch(chrome.runtime.getURL('quiz_anomaly_check.js'))
    .then(r => r.text());

  // userGesture:true allows window.open() for the PDF report.
  await sendCmd({ tabId }, 'Runtime.evaluate', {
    expression: `(function(){ window.__NQ_AUTH = ${JSON.stringify(auth)}; ${code}\n__nqRun(); })()`,
    awaitPromise: false,
    userGesture: true,
  });

  // Debugger stays attached so window.open() keeps working when the user
  // clicks "Print PDF" later (same effect as leaving DevTools open).
}

// ── Message handler (called by popup.js) ─────────────────────────────────────
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg.type !== 'run') return false;
  runAnalysis(msg.tabId)
    .then(() => sendResponse({ ok: true }))
    .catch(e => sendResponse({ error: e.message }));
  return true;
});

// ── Cleanup when Chrome forcibly detaches us ─────────────────────────────────
chrome.debugger.onDetach.addListener((source, reason) => {
  if (source.tabId === attachedTabId) {
    console.log('[NQ bg] tab detached:', reason);
    attachedTabId = null;
  }
});
