﻿// ==UserScript==
// @name         Canvas NQ — Session Anomaly Detector
// @namespace    https://learn.ontariotechu.ca
// @version      1.0
// @description  Flags academic integrity anomalies in Canvas New Quizzes session logs
// @author       Eric Rapos
// @match        https://quiz-lti-yul-prod.instructure.com/*
// @grant        none
// @run-at       document-idle
// ==/UserScript==

async function __nqRun() {
  // ── Configuration ────────────────────────────────────────────────────
  const MAX_STUDENTS = 9999;
  const PARALLEL     = 10;
  const BURST_SEC    = 30;
  const GAP_MIN      = 10;

  const DEFAULT_BURST_THRESHOLD = 10;

  const wait = ms => new Promise(r => setTimeout(r, ms));

  // ── Config UI ────────────────────────────────────────────────────────
  function showConfigModal(defaultThreshold) {
    return new Promise((resolve, reject) => {
      const overlay = document.createElement('div');
      overlay.style.cssText = [
        'position:fixed;inset:0;background:rgba(0,0,0,.55)',
        'z-index:99999;display:flex;align-items:center;justify-content:center',
        'font-family:sans-serif'
      ].join(';');

      overlay.innerHTML = `
        <div style="background:#fff;border-radius:10px;width:100%;max-width:420px;
                    box-shadow:0 8px 40px rgba(0,0,0,.35);overflow:hidden">

          <div style="background:#003e6b;color:#fff;padding:16px 24px">
            <div style="font-size:11px;opacity:.65;margin-bottom:2px">New Quizzes</div>
            <div style="font-size:18px;font-weight:bold">Session Log Anomaly Detector</div>
          </div>

          <div style="padding:24px 28px">
            <p style="margin:0 0 22px;font-size:14px;color:#333;line-height:1.55">
              How many questions answered within
              <strong>30 seconds</strong> should be flagged?
            </p>

            <div style="display:flex;align-items:center;gap:18px;margin-bottom:6px">
              <input id="cfg_slider" type="range" min="1" max="20" value="${defaultThreshold}"
                style="flex:1;accent-color:#003e6b;cursor:pointer">
              <span id="cfg_val"
                style="font-size:36px;font-weight:700;color:#003e6b;min-width:1.2ch;text-align:right;line-height:1">
                ${defaultThreshold}
              </span>
            </div>

            <div style="display:flex;justify-content:space-between;font-size:11px;color:#aaa;margin-bottom:18px">
              <span>1 — very sensitive</span>
              <span>20 — lenient</span>
            </div>

            <div id="cfg_hint"
              style="font-size:12px;color:#555;background:#f5f7fa;border-radius:6px;padding:10px 14px;line-height:1.7">
            </div>
          </div>

          <div style="padding:14px 24px;background:#f5f7fa;border-top:1px solid #e0e7ef;
                      display:flex;justify-content:flex-end;gap:10px">
            <button id="cfg_cancel" style="padding:9px 20px;border:1px solid #ccc;background:#fff;
              border-radius:4px;cursor:pointer;font-size:13px;color:#555">Cancel</button>
            <button id="cfg_run" style="padding:9px 24px;background:#003e6b;color:#fff;
              border:none;border-radius:4px;cursor:pointer;font-size:13px;font-weight:600">
              ▶ Run Analysis</button>
          </div>
        </div>`;

      document.body.appendChild(overlay);

      const slider = document.getElementById('cfg_slider');
      const valEl  = document.getElementById('cfg_val');
      const hint   = document.getElementById('cfg_hint');

      function updateHint(v) {
        valEl.textContent = v;
        hint.innerHTML =
          '<span style="color:#b71c1c">🔴 Red: ' + (v + 2) + '+ questions in 30 s</span><br>' +
          '<span style="color:#e65100">🟡 Yellow: ' + v + '–' + (v + 1) + ' questions in 30 s</span>';
      }

      updateHint(parseInt(slider.value, 10));
      slider.addEventListener('input', () => updateHint(parseInt(slider.value, 10)));

      document.getElementById('cfg_run').onclick = () => {
        overlay.remove();
        resolve(parseInt(slider.value, 10));
      };
      document.getElementById('cfg_cancel').onclick = () => {
        overlay.remove();
        reject(new Error('Cancelled'));
      };
    });
  }

  if (!location.href.includes('moderat')) {
    alert('Navigate to the Moderate tab of the quiz first, then re-run.');
    return;
  }

  let threshold;
  try { threshold = await showConfigModal(DEFAULT_BURST_THRESHOLD); } catch { return; }

  const BURST_COUNT_YELLOW = threshold;
  const BURST_COUNT_RED    = threshold + 2;

  // ── Helpers ──────────────────────────────────────────────────────────

  function getStudentsFromFiber() {
    const students = [];
    for (const row of document.querySelectorAll('table tbody tr')) {
      const logBtn  = row.querySelector('[data-automation="sdk-moderation-moderate-session-log-link"]');
      const nameBtn = row.querySelector('[data-automation="sdk-moderate-accommodations-edit"]');
      if (!logBtn) continue;
      const name = nameBtn ? nameBtn.textContent.trim() : 'Unknown';
      const fk = Object.keys(logBtn).find(k => k.startsWith('__reactFiber'));
      if (!fk) continue;
      let node = logBtn[fk];
      while (node) {
        const ids = node.memoizedProps && node.memoizedProps.rowData && node.memoizedProps.rowData.quizSessionIds;
        if (ids && ids.length) { students.push({ name, sessionIds: ids.slice() }); break; }
        node = node.return;
      }
    }
    return students;
  }

  function getModerationState() {
    const logBtn = document.querySelector('[data-automation="sdk-moderation-moderate-session-log-link"]');
    if (!logBtn) return { totalPages: 1 };
    const fk = Object.keys(logBtn).find(k => k.startsWith('__reactFiber'));
    if (!fk) return { totalPages: 1 };
    let result = { totalPages: 1 };
    let node = logBtn[fk];
    while (node) {
      const p = node.memoizedProps || {};
      if (p.totalPages) result.totalPages = p.totalPages;
      node = node.return;
    }
    return result;
  }

  function findPageButton(pageNum) {
    for (const btn of document.querySelectorAll('button')) {
      if (btn.textContent.trim() === String(pageNum) &&
          !btn.disabled && btn.getAttribute('aria-disabled') !== 'true') return btn;
    }
    return null;
  }

  // Locate the app's Redux store by scanning the React fiber tree for a node whose
  // props carry { store: { getState, dispatch } }. The store holds the moderate-scoped
  // token + quizId we use to pull the whole roster from quiz-api in one shot.
  function getReduxStore() {
    const anchor = document.querySelector('[data-automation="sdk-moderation-moderate-session-log-link"]')
                || document.querySelector('#content') || document.body;
    const fk = Object.keys(anchor).find(k => k.startsWith('__reactFiber') || k.startsWith('__reactContainer'));
    if (!fk) return null;
    let root = anchor[fk];
    while (root && root.return) root = root.return;

    let found = null;
    (function scan(fiber, depth) {
      if (!fiber || found || depth > 500) return;
      const p = fiber.memoizedProps;
      if (p) {
        if (p.store && typeof p.store.getState === 'function' && typeof p.store.dispatch === 'function') { found = p.store; return; }
        if (p.value && p.value.store && typeof p.value.store.getState === 'function') { found = p.value.store; return; }
      }
      scan(fiber.child, depth + 1);
      scan(fiber.sibling, depth + 1);
    })(root, 0);
    return found;
  }

  // Fetch the entire roster via the moderate-scoped token — every quiz_session carries
  // the student's name in metadata.user_full_name. Sessions are grouped per student
  // (a student with multiple attempts has multiple session IDs). No page navigation.
  async function fetchRoster(modToken, quizId, host) {
    const byUser = {};   // user_uuid -> { name, sessionIds, rosterSessions }
    const order  = [];   // preserve first-seen order
    const hdrs = { authorization: modToken, authtype: 'Signature', accept: 'application/json' };
    let totalSeen = 0, skippedNoParticipant = 0;

    for (let page = 1; page <= 50; page++) {
      const url = host + '/api/quizzes/' + quizId + '/quiz_sessions?per_page=200&page=' + page;
      const resp = await fetch(url, { headers: hdrs });
      if (!resp.ok) {
        const body = await resp.text().catch(() => '');
        throw new Error('roster HTTP ' + resp.status + ': ' + body.slice(0, 140));
      }
      const data = await resp.json();
      const sessions = Array.isArray(data) ? data : (data.quiz_sessions || []);
      if (!sessions.length) break;

      for (const s of sessions) {
        totalSeen++;
        // Skip sessions with no resolvable participant: Canvas Test Student / Student-View /
        // preview / removed-user sessions carry no metadata.user_full_name (and 404 on /log).
        // They are never real student attempts.
        const meta = s.metadata || {};
        if (!meta.user_full_name || !s.start_at) { skippedNoParticipant++; continue; }

        const uid  = meta.user_uuid || ('sid_' + s.id);
        if (!byUser[uid]) {
          byUser[uid] = { name: meta.user_full_name || 'Unknown', sessionIds: [], rosterSessions: {},
                          score: null, pointsPossible: null, percentage: null };
          order.push(uid);
        }
        byUser[uid].sessionIds.push(String(s.id));
        const ar = s.authoritative_result || null;
        byUser[uid].rosterSessions[String(s.id)] = {
          createdAt:   s.start_at     || null,
          submittedAt: s.submitted_at || null,
          status:      s.status       || 'unknown',
          elapsedTime: s.elapsed_time != null ? s.elapsed_time : null,
          itemsCount:  s.session_items_count != null ? s.session_items_count : null,
          score:       ar && ar.score != null ? ar.score : null,
          pointsPossible: ar && ar.points_possible != null ? ar.points_possible : null,
          percentage:  ar && ar.percentage != null ? ar.percentage : null,
        };
        // Student-level score = highest-scoring attempt (Canvas keeps the highest)
        if (ar && ar.score != null && (byUser[uid].score == null || ar.score > byUser[uid].score)) {
          byUser[uid].score         = ar.score;
          byUser[uid].pointsPossible = ar.points_possible != null ? ar.points_possible : null;
          byUser[uid].percentage    = ar.percentage != null ? ar.percentage : null;
        }
      }
      setProgress('Phase 1 of 2 — fetching roster', 'Loaded ' + order.length + ' students…', order.length, order.length);
      if (sessions.length < 200) break;
    }
    console.log('[quiz] roster: ' + totalSeen + ' sessions → ' + order.length + ' real students, ' +
                skippedNoParticipant + ' test/preview/no-participant (skipped)');
    return order.map(uid => byUser[uid]);
  }

  // PRIMARY roster source: the quiz-lti participants endpoint. Returns enrolled participants
  // already sorted by Canvas sortable_name ("Last, First" — handles compound surnames), each
  // with name + their quiz_api_quiz_session_id(s) + per-session timing. Same auth as /log.
  // (Carries no score — that's merged in separately from the quiz-api roster.)
  async function fetchParticipants(assignmentId) {
    const students = [];   // kept in delivered (sortable_name) order
    for (let page = 1; page <= 100; page++) {
      const url = ltiHost + '/api/assignments/' + assignmentId + '/participants?page=' + page;
      const resp = await fetch(url, { headers: ltiHeaders });
      if (!resp.ok) {
        const body = await resp.text().catch(() => '');
        throw new Error('participants HTTP ' + resp.status + ': ' + body.slice(0, 140));
      }
      const data = await resp.json();
      const arr = Array.isArray(data) ? data : (data.participants || []);
      if (!arr.length) break;

      for (const p of arr) {
        const psList = p.participant_sessions || [];
        const sessionIds = [];
        const rosterSessions = {};
        for (const ps of psList) {
          const sid = ps.quiz_api_quiz_session_id != null ? String(ps.quiz_api_quiz_session_id) : null;
          if (!sid) continue;
          sessionIds.push(sid);
          rosterSessions[sid] = {
            createdAt:   ps.created_at   || null,
            submittedAt: ps.submitted_at || null,
            status:      ps.status       || 'unknown',
            timezone:    ps.timezone     || null,
          };
        }
        if (!sessionIds.length) continue;  // assigned but never attempted — nothing to analyse
        students.push({
          name: (p.user && p.user.full_name) || 'Unknown',
          sessionIds, rosterSessions,
          score: null, pointsPossible: null, percentage: null,
        });
      }
      setProgress('Phase 1 of 2 — fetching roster', 'Loaded ' + students.length + ' students…', students.length, students.length);
    }
    return students;
  }

  // Build a session-id → score map from the quiz-api roster (the only source with
  // authoritative_result). Used to enrich the participant roster with scores.
  async function fetchScoreMap(quizId, modToken, host) {
    const map = {};
    if (!quizId || !modToken) return map;
    const hdrs = { authorization: modToken, authtype: 'Signature', accept: 'application/json' };
    for (let page = 1; page <= 50; page++) {
      const resp = await fetch(host + '/api/quizzes/' + quizId + '/quiz_sessions?per_page=200&page=' + page, { headers: hdrs });
      if (!resp.ok) break;
      const data = await resp.json();
      const sessions = Array.isArray(data) ? data : (data.quiz_sessions || []);
      if (!sessions.length) break;
      for (const s of sessions) {
        const ar = s.authoritative_result;
        if (ar && ar.score != null) {
          map[String(s.id)] = {
            score:          ar.score,
            pointsPossible: ar.points_possible != null ? ar.points_possible : null,
            percentage:     ar.percentage     != null ? ar.percentage     : null,
          };
        }
      }
      if (sessions.length < 200) break;
    }
    return map;
  }

  // Merge scores into roster students (highest attempt wins, matching Canvas policy)
  function attachScores(students, scoreMap) {
    for (const st of students) {
      for (const sid of st.sessionIds) {
        const sc = scoreMap[sid];
        if (sc && sc.score != null && (st.score == null || sc.score > st.score)) {
          st.score = sc.score; st.pointsPossible = sc.pointsPossible; st.percentage = sc.percentage;
        }
      }
    }
  }

  function waitUntil(condFn, timeout) {
    return new Promise(resolve => {
      const deadline = Date.now() + timeout;
      const check = () => {
        if (condFn()) { resolve(true); return; }
        if (Date.now() >= deadline) { resolve(false); return; }
        setTimeout(check, 300);
      };
      check();
    });
  }

  // ── Progress overlay ─────────────────────────────────────────────────
  const prog = document.createElement('div');
  prog.style.cssText = [
    'position:fixed;top:20px;left:50%;transform:translateX(-50%)',
    'background:#003e6b;color:#fff;padding:16px 28px',
    'border-radius:8px;font-family:sans-serif;font-size:13px',
    'z-index:99999;box-shadow:0 4px 16px rgba(0,0,0,.35)',
    'min-width:380px;text-align:center;line-height:1.6'
  ].join(';');
  document.body.appendChild(prog);

  function setProgress(phase, label, done, total) {
    const pct   = total > 0 ? Math.round((done / total) * 100) : 0;
    const inner = total > 0
      ? '<div style="margin-top:8px;background:rgba(255,255,255,.2);border-radius:4px;height:6px;overflow:hidden">' +
        '<div style="background:#4fc3f7;height:100%;width:' + pct + '%;transition:width .3s"></div></div>' +
        '<div style="font-size:11px;opacity:.7;margin-top:4px">' + done + ' / ' + total + ' (' + pct + '%)</div>'
      : '';
    prog.innerHTML =
      '<div style="font-size:11px;opacity:.65;margin-bottom:3px">' + phase + '</div>' +
      '<b>' + label + '</b>' + inner;
  }

  // ════════════════════════════════════════════════════════════════════════
  //  AUTH — captured by background.js from real network traffic. The moderation
  //  SDK now renders inline in the main Canvas page (no separate LTI iframe), and
  //  its tokens aren't reachable via simple fiber-prop walks anymore, so
  //  background.js sniffs them off the page's own quiz-lti/quiz-api requests
  //  (see captureAuth() there) and hands them to us as window.__NQ_AUTH.
  // ════════════════════════════════════════════════════════════════════════
  const NQ_AUTH = window.__NQ_AUTH;
  if (!NQ_AUTH || !NQ_AUTH.lti || !NQ_AUTH.api || !NQ_AUTH.nativeLaunch) {
    document.body.removeChild(prog);
    alert('Could not read auth tokens. Make sure you are on the Moderate tab and try again.');
    return;
  }

  // launch_token is a one-time-use nonce — it is NOT reusable across students. Its
  // claims carry no student/session info at all (just course context + instructor
  // identity + a random jti), so the page mints a fresh one per view by POSTing the
  // same LTI launch payload to /api/native/launch each time. We replay that same
  // captured POST body ourselves, once per student right before fetching their log.
  //
  // Crucially, the native/launch response returns TWO tokens, both scoped to that
  // one mint call: `launch_token` (the nonce for the /log query param) AND
  // `access_token` (a short-lived Bearer token that MUST be used as the /log
  // request's Authorization header instead of the general captured quiz-lti auth —
  // using the wrong one is indistinguishable from an invalid nonce and also 404s).
  // Confirmed live: matching access_token + launch_token from the same mint → 200;
  // mismatched (old captured auth + fresh launch_token) → 404 every time.
  async function mintLaunchToken() {
    const nl = NQ_AUTH.nativeLaunch;
    const headers = { 'Authorization': nl.authorization, 'Content-Type': 'application/json', 'accept': 'application/json' };
    if (nl.xDomain) headers['x-domain'] = nl.xDomain;
    const resp = await fetch(nl.host + '/api/native/launch', { method: 'POST', headers, body: nl.body });
    if (!resp.ok) throw new Error('native/launch HTTP ' + resp.status);
    const json = await resp.json();
    if (!json.launch_token) throw new Error('no launch_token in native/launch response');
    if (!json.access_token) throw new Error('no access_token in native/launch response');
    return { launchToken: json.launch_token, accessToken: json.access_token };
  }

  // Headers for quiz-lti calls — captured verbatim off a real request (already
  // includes the "Bearer " prefix and correct x-domain value).
  const ltiHeaders = {
    'Authorization': NQ_AUTH.lti.authorization,
    'accept': 'application/json',
    'content-type': 'application/json',
  };
  if (NQ_AUTH.lti.xDomain) ltiHeaders['x-domain'] = NQ_AUTH.lti.xDomain;
  const ltiHost = NQ_AUTH.lti.host;

  // Moderate-scoped quiz-api token + host, captured from the roster fetch
  const moderateToken = NQ_AUTH.api.authorization;
  const apiHost        = NQ_AUTH.api.host;

  // quizId lives in the moderate token's own payload (resource_id claim) — no
  // Redux store to read it from anymore.
  let quizId = null;
  try {
    const payload = JSON.parse(
      atob(moderateToken.split('.')[1].replace(/-/g, '+').replace(/_/g, '/'))
    );
    quizId = payload.resource_id != null ? String(payload.resource_id) : null;
  } catch (e) { /* ignore */ }

  // Assignment id from the moderation URL — the path is
  // /courses/{courseId}/assignments/{assignmentId}/moderation/{quizId}, so the
  // segment right before "/moderation/" is the real assignment id (the one after
  // it is the quiz id, a different number). Drives the participants endpoint,
  // which returns the roster in true sortable_name order.
  const amatch = location.pathname.match(/\/assignments\/(\d+)\/moderation\//);
  const assignmentId = amatch ? amatch[1] : null;

  // Quiz title for PDF headers — assignment API is most reliable; DOM + document.title are fallbacks
  let quizTitle = null;
  if (assignmentId) {
    try {
      const _tResp = await fetch(ltiHost + '/api/assignments/' + assignmentId,
        { headers: ltiHeaders });
      if (_tResp.ok) {
        const _tData = await _tResp.json();
        quizTitle = _tData.title || _tData.name || null;
        if (quizTitle) console.log('[quiz] title from API:', quizTitle);
      }
    } catch (e) { /* ignore */ }
  }
  // Each quiz session in the roster API has a .quiz.title field — fetch one session to get it
  if (!quizTitle && moderateToken && quizId) {
    try {
      const _qResp = await fetch(
        apiHost + '/api/quizzes/' + quizId + '/quiz_sessions?per_page=1&page=1',
        { headers: { authorization: moderateToken, authtype: 'Signature', accept: 'application/json' } });
      if (_qResp.ok) {
        const _qData = await _qResp.json();
        const _qss = Array.isArray(_qData) ? _qData : (_qData.quiz_sessions || []);
        if (_qss[0] && _qss[0].quiz && _qss[0].quiz.title) {
          quizTitle = _qss[0].quiz.title;
          console.log('[quiz] title from session data:', quizTitle);
        }
      }
    } catch (e) { /* ignore */ }
  }
  if (!quizTitle) {
    const _h = document.querySelector('h1, h2');
    const _ht = _h ? _h.textContent.trim() : '';
    if (_ht && _ht.toLowerCase() !== 'quizzes' && _ht.length > 2) quizTitle = _ht;
  }
  if (!quizTitle) {
    const _dt = (document.title || '').split(/\s*[|\-]/)[0].trim();
    if (_dt && _dt.toLowerCase() !== 'quizzes' && _dt.toLowerCase() !== 'canvas') quizTitle = _dt || null;
  }

  // ════════════════════════════════════════════════════════════════════════
  //  PHASE 1 — collect students
  //  Primary: quiz-lti participants endpoint (sortable_name order) + quiz-api score map.
  //  Fallbacks: quiz-api roster, then DOM page-walk.
  // ════════════════════════════════════════════════════════════════════════
  let allStudents = [];

  if (assignmentId) {
    setProgress('Phase 1 of 2 — fetching roster', 'Querying participants…', 0, 0);
    try {
      allStudents = await fetchParticipants(assignmentId);
      const scoreMap = await fetchScoreMap(quizId, moderateToken, apiHost);
      attachScores(allStudents, scoreMap);
      console.log('[quiz] roster: ' + allStudents.length + ' students (sortable_name order) · ' +
                  Object.keys(scoreMap).length + ' scores merged');
    } catch (e) {
      console.warn('[quiz] participants fetch failed, falling back:', e);
      allStudents = (moderateToken && quizId)
        ? await fetchRoster(moderateToken, quizId, apiHost)
        : await collectStudentsViaDom();
    }
  } else if (moderateToken && quizId) {
    console.warn('[quiz] no assignment id in URL — using quiz-api roster (id order)');
    allStudents = await fetchRoster(moderateToken, quizId, apiHost);
  } else {
    console.warn('[quiz] no assignment id or moderate token — using page navigation');
    allStudents = await collectStudentsViaDom();
  }

  if (allStudents.length > MAX_STUDENTS) allStudents = allStudents.slice(0, MAX_STUDENTS);
  const totalFound = allStudents.length;

  // Legacy fallback: walk the moderation table pages via the DOM/fiber
  async function collectStudentsViaDom() {
    const collected = [];
    const { totalPages } = getModerationState();
    setProgress('Phase 1 of 2 — reading student list', 'Found ' + totalPages + ' page(s)…', 0, 0);
    await wait(300);

    paginationLoop: for (let pageNum = 1; pageNum <= totalPages; pageNum++) {
      const pageStudents = getStudentsFromFiber();
      if (!pageStudents.length) break;
      setProgress('Phase 1 of 2 — page ' + pageNum + ' of ' + totalPages,
        'Read ' + pageStudents.length + ' students', collected.length,
        Math.min(MAX_STUDENTS, collected.length + pageStudents.length));
      for (const s of pageStudents) {
        if (collected.length >= MAX_STUDENTS) break paginationLoop;
        collected.push(s);
      }
      if (collected.length >= MAX_STUDENTS) break;
      if (pageNum < totalPages) {
        const firstNameBefore = pageStudents[0] && pageStudents[0].name;
        const nextBtn = findPageButton(pageNum + 1);
        if (!nextBtn) break;
        nextBtn.click();
        const changed = await waitUntil(() => {
          const s = getStudentsFromFiber();
          return s.length > 0 && s[0].name !== firstNameBefore;
        }, 10000);
        if (!changed) break;
        await wait(600);
      }
    }
    return collected;
  }

  // ════════════════════════════════════════════════════════════════════════
  //  PHASE 2 — fetch event logs via quiz-api (no Bearer prefix for quiz-api)
  // ════════════════════════════════════════════════════════════════════════
  let completed = 0;

  function updatePhase2(name) {
    setProgress('Phase 2 of 2 — fetching logs (' + PARALLEL + ' concurrent)', name, completed, totalFound);
  }

  // Exchange for a per-session quiz-api JWT via the quiz-lti log endpoint.
  // Also returns participant_session timing for accurate duration.
  // Each mint call produces its own independent (launch_token, access_token) pair,
  // so concurrent students don't collide — the /log call MUST use the access_token
  // from that SAME mint response as its Authorization header, not the general
  // captured quiz-lti auth (that combination 404s even though the nonce is valid).
  async function getSessionInfo(sessionId) {
    const { launchToken: freshLaunchToken, accessToken } = await mintLaunchToken();
    const url = ltiHost + '/api/quiz_sessions/' + sessionId +
                '/log?launch_token=' + encodeURIComponent(freshLaunchToken);
    const headers = { 'Authorization': 'Bearer ' + accessToken, 'accept': 'application/json' };
    if (NQ_AUTH.lti.xDomain) headers['x-domain'] = NQ_AUTH.lti.xDomain;
    const resp = await fetch(url, { headers });
    if (!resp.ok) throw new Error('log HTTP ' + resp.status + ' for session ' + sessionId);
    const json = await resp.json();
    if (!json.token) throw new Error('no token in log response for session ' + sessionId);
    const ps = json.participant_session || {};
    return {
      token:       json.token,
      createdAt:   ps.created_at   || null,
      submittedAt: ps.submitted_at || null,
      status:      ps.status       || 'unknown',
      timezone:    ps.timezone     || null,
    };
  }

  // Fetch all events for one session from quiz-api.
  // IMPORTANT: quiz-api expects the raw JWT in 'authorization' — NO "Bearer " prefix.
  // The endpoint caps each page at 200 events. The DynamoDB cursor for the next
  // page is returned in RESPONSE HEADERS (x-last-evaluated-hash-key / -range-key),
  // NOT in the body. The hash key is "sessionId|UUID" — must be passed back verbatim.
  async function fetchSessionEvents(sessionId, sessionToken) {
    const all = [];
    let hashKey = null, rangeKey = null;

    for (let page = 0; page < 100; page++) {
      let url = apiHost + '/api/quiz_sessions/' + sessionId + '/quiz_session_events?per_page=200';
      if (hashKey) {
        url += '&last_evaluated_hash_key=' + encodeURIComponent(hashKey) +
               '&last_evaluated_range_key=' + encodeURIComponent(rangeKey);
      }
      const resp = await fetch(url, {
        headers: { authorization: sessionToken, authtype: 'Signature', accept: 'application/json' }
      });
      if (!resp.ok) {
        const body = await resp.text().catch(() => '');
        throw new Error('events HTTP ' + resp.status + ' for session ' + sessionId + ': ' + body.slice(0, 120));
      }
      const data = await resp.json();
      const evs = Array.isArray(data) ? data : (data.quiz_session_events || data.events || []);
      for (const e of evs) all.push(Object.assign({}, e, { _sid: String(sessionId) }));

      // Next-page cursor lives in response headers
      hashKey  = resp.headers.get('x-last-evaluated-hash-key');
      rangeKey = resp.headers.get('x-last-evaluated-range-key');
      if (!hashKey || !evs.length) break;
    }
    return all;
  }

  // Session items (quiz questions + choices) — loaded once per quiz run, shared across all students.
  // Maps item_id → { choices: { choice_id → item_body } } for resolving answer UUID → readable text.
  let itemMap = null;
  let itemMapPromise = null;
  function loadItemMap(sessionId, sessionToken) {
    if (itemMap !== null) return Promise.resolve();
    if (itemMapPromise) return itemMapPromise;
    itemMapPromise = (async () => {
      // Try multiple candidate URLs in order; stop at the first that returns items.
      const candidates = [
        [apiHost + '/api/quiz_sessions/' + sessionId + '/session_items',
          { authorization: sessionToken, authtype: 'Signature', accept: 'application/json' }],
        quizId ? [apiHost + '/api/quizzes/' + quizId + '/session_items',
          { authorization: moderateToken, authtype: 'Signature', accept: 'application/json' }] : null,
        quizId ? [apiHost + '/api/quizzes/' + quizId + '/items',
          { authorization: moderateToken, authtype: 'Signature', accept: 'application/json' }] : null,
      ].filter(Boolean);

      for (const [url, hdrs] of candidates) {
        try {
          const resp = await fetch(url, { headers: hdrs });
          const tag = url.split('/api/')[1];
          if (!resp.ok) { console.log('[quiz] session_items', tag, '→ HTTP', resp.status); continue; }
          const raw = await resp.json();
          const arr = Array.isArray(raw) ? raw
            : (raw.session_items || raw.items || raw.quiz_items || raw.questions || raw.data || []);
          // Log what we got so the URL/shape can be identified if items = 0
          console.log('[quiz] session_items', tag, '→',
            Array.isArray(raw) ? raw.length + ' (array)' : 'object keys: ' + Object.keys(raw).join(', '),
            '| arr.length =', arr.length);
          if (!arr.length) continue;
          const map = {};
          let _dbgNoBlank = false;
          for (const item of arr) {
            const intData = item.item && item.item.interaction_data;
            if (!intData) continue;
            const blanks = intData.blanks || [];

            // Dropdown / fill-in-blank: each blank has its own id and choices array
            for (const blank of blanks) {
              if (!blank.id) continue;
              const choices = {};
              for (const c of (blank.choices || [])) {
                if (c.id) choices[c.id] = c.item_body || '';
              }
              map[blank.id] = { choices };
            }

            // Checkbox / MCSS: choices sit directly in interaction_data (no blanks)
            if (!blanks.length && intData.choices && intData.choices.length) {
              const itemId = (item.item && item.item.id) || item.id || item.item_id || null;
              if (!_dbgNoBlank) {
                _dbgNoBlank = true;
                console.log('[quiz] session_items no-blank item — top keys:', Object.keys(item).join(', '),
                  '| item.item keys:', Object.keys(item.item || {}).join(', '),
                  '| resolved itemId:', itemId,
                  '| first 3 choice IDs:', (intData.choices || []).slice(0, 3).map(function(c){return c.id;}).join(', '));
              }
              if (itemId) {
                const choices = {};
                for (const c of intData.choices) {
                  if (c.id) choices[c.id] = c.item_body || '';
                }
                map[String(itemId)] = { choices };
              }
            }
          }
          if (Object.keys(map).length) {
            itemMap = map;
            console.log('[quiz] session_items loaded:', Object.keys(map).length, 'items from', tag);
            return;
          }
        } catch (e) { console.warn('[quiz] session_items error on', url.split('/api/')[1], ':', e.message); }
      }
      itemMap = {};
      console.warn('[quiz] session_items: no items found from any endpoint — answers will show raw UUIDs');
    })();
    return itemMapPromise;
  }

  async function analyseStudent(student) {
    const allRaw = [];
    const sessionInfos = [];
    const usableSessionIds = [];
    for (const sid of student.sessionIds) {
      let info;
      try {
        info = await getSessionInfo(sid);
      } catch (e) {
        // No log for this session (untaken/placeholder) — skip it rather than failing the student
        if (String(e).indexOf('404') >= 0) continue;
        throw e;
      }
      usableSessionIds.push(String(sid));
      sessionInfos.push({ sessionId: String(sid), createdAt: info.createdAt,
                          submittedAt: info.submittedAt, status: info.status,
                          timezone: info.timezone });
      const evs = await fetchSessionEvents(sid, info.token);
      for (const e of evs) allRaw.push(e);
      // Load session items (quiz questions + answer choices) once for the whole quiz
      await loadItemMap(sid, info.token);
    }
    if (!usableSessionIds.length) throw new Error('no accessible session log (not attempted)');
    return computeStats(usableSessionIds, allRaw, sessionInfos);
  }

  updatePhase2('Starting…');

  const results = [];
  for (let i = 0; i < allStudents.length; i += PARALLEL) {
    const batch = allStudents.slice(i, i + PARALLEL);
    const batchResults = await Promise.all(
      batch.map(s => {
        const rosterInfo = { name: s.name, score: s.score != null ? s.score : null,
                             pointsPossible: s.pointsPossible != null ? s.pointsPossible : null,
                             percentage: s.percentage != null ? s.percentage : null };
        return analyseStudent(s)
          .then(stats => Object.assign({}, rosterInfo, { error: null }, stats))
          .catch(e    => Object.assign({}, rosterInfo, { error: String(e), flagLevel: 'error' }))
          .finally(() => { completed++; updatePhase2(s.name); });
      })
    );
    for (const r of batchResults) results.push(r);
  }

  document.body.removeChild(prog);
  showReport(results, totalFound);

  // ════════════════════════════════════════════════════════════════════════
  //  PARSING — raw quiz-api events → normalised internal objects
  //
  //  Event types observed:
  //    SESSION_STARTED_OR_RESUMED_EVENT  — session start / resume
  //    RESPONSE                          — student answered a question
  //    PAGE_BLURRED_EVENT                — student left the tab/window
  //
  //  Timestamps: event_data.client_timestamp (ISO string) is preferred.
  //  created_at has the format "ISO_TIMESTAMP|NUMERIC" — take the part before |.
  // ════════════════════════════════════════════════════════════════════════
  function parseApiEvents(rawEvents) {
    if (!rawEvents.length) return { events: [], userAgents: [], startUserAgents: [], browserSessions: [] };

    const userAgentSet     = new Set();  // UAs from ALL events (incl. CLDB-wrapped RESPONSE events)
    const startUserAgentSet = new Set(); // UAs from SESSION_STARTED events only (the "real" browser)
    const browserSessSet   = new Set();

    function getTs(ev) {
      const s = (ev.event_data && ev.event_data.client_timestamp)
              || (ev.created_at && ev.created_at.split('|')[0])
              || null;
      return s ? new Date(s).getTime() : null;
    }

    rawEvents.sort((a, b) => (getTs(a) || 0) - (getTs(b) || 0));
    const startTs = getTs(rawEvents[0]) || 0;

    const events = [];
    for (const ev of rawEvents) {
      const ts  = getTs(ev);
      const sec = (ts !== null && !isNaN(ts)) ? Math.round((ts - startTs) / 1000) : null;
      const etype = ev.event_type || '';
      const data  = ev.event_data  || {};

      if (data.user_agent)       userAgentSet.add(data.user_agent);
      if (data.browser_session_id) browserSessSet.add(data.browser_session_id);

      if (etype === 'SESSION_STARTED_OR_RESUMED_EVENT') {
        // Collect UA + browser session from start events too (may differ from RESPONSE events)
        if (data.user_agent) userAgentSet.add(data.user_agent);
        if (data.user_agent) startUserAgentSet.add(data.user_agent);
        if (data.browser_session_id) browserSessSet.add(data.browser_session_id);
        events.push({ type: 'session_start', time: sec !== null ? sec : 0, abs: ts,
                      sessionId: String(ev._sid),
                      bsid: data.browser_session_id || null,
                      ua: data.user_agent || null,
                      ip: data.ip_address || data.ip_addr || data.ip || null,
                      raw: etype });

      } else if (etype === 'RESPONSE') {
        // Use position (1-based quiz order) as the key — human-readable and stable.
        // Fall back to item_id if position is absent.
        const pos = data.position != null ? data.position : null;
        const qId = pos != null ? String(pos)
                  : data.item_id != null ? String(data.item_id) : null;
        if (qId !== null) {
          // Answer is in user_response.value; fall back to whole user_response if .value absent
          const _ur = data.user_response || null;
          const answerVal = _ur != null
            ? (_ur.value !== undefined ? _ur.value : _ur)
            : null;
          events.push({ type: 'answer', q: qId, pos: pos, time: sec, abs: ts,
            bsid: data.browser_session_id || null, answerVal, raw: etype });
        }

      } else if (etype === 'PAGE_BLURRED_EVENT') {
        events.push({ type: 'away', time: sec, abs: ts, bsid: data.browser_session_id || null, raw: etype });

      } else if (etype === 'PAGE_FOCUSED_EVENT') {
        events.push({ type: 'focused', time: sec, abs: ts, bsid: data.browser_session_id || null, raw: etype });

      } else if (etype.includes('SUBMIT') || etype.includes('FINISH')) {
        events.push({ type: 'session_submit', time: sec, abs: ts, bsid: data.browser_session_id || null, raw: etype });

      } else {
        if (sec !== null) events.push({ type: 'other', time: sec, raw: etype });
      }
    }

    return {
      events,
      userAgents:      Array.from(userAgentSet),
      startUserAgents: Array.from(startUserAgentSet),
      browserSessions: Array.from(browserSessSet),
    };
  }

  // ════════════════════════════════════════════════════════════════════════
  //  SESSION ANOMALY DETECTION
  // ════════════════════════════════════════════════════════════════════════
  // A new browser_session_id from a page refresh is NOT inherently suspicious.
  // We only flag specific misconduct patterns:
  //   1. Platform change  — different browser or OS across session IDs
  //   2. Concurrent sessions — two IDs have overlapping time ranges
  //   3. Interleaving — A → B → A event pattern (covers ghost/proxy scenario)
  function detectSessionAnomalies(events, allBrowserSessions) {
    const flags = [];

    // IP anomaly — multiple distinct IPs is a red flag regardless of session count
    const seenIPs = new Set();
    for (const e of events) {
      if (e.type === 'session_start' && e.ip) seenIPs.add(e.ip);
    }
    if (seenIPs.size > 1) {
      flags.push({ level: 'red', msg: 'multiple IP addresses used: ' + Array.from(seenIPs).join(', ') });
    }

    if (allBrowserSessions.length <= 1) return flags;

    // Format elapsed seconds (since the attempt began) as M:SS or H:MM:SS — Canvas shows
    // event times this way in its log, so these line up with what the instructor sees.
    function fmtElapsed(sec) {
      if (sec == null || isNaN(sec)) return '?:??';
      const s = Math.max(0, Math.round(sec));
      const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), ss = s % 60;
      const p = function(n) { return n < 10 ? '0' + n : '' + n; };
      return h > 0 ? h + ':' + p(m) + ':' + p(ss) : m + ':' + p(ss);
    }
    function minOf(a) { let m = a[0]; for (let i = 1; i < a.length; i++) if (a[i] < m) m = a[i]; return m; }
    function maxOf(a) { let m = a[0]; for (let i = 1; i < a.length; i++) if (a[i] > m) m = a[i]; return m; }

    // Build per-session profile from all events that carry a bsid, using elapsed (relative) times
    const sessMap = {};
    for (const e of events) {
      const bsid = e.bsid || null;
      if (!bsid) continue;
      if (!sessMap[bsid]) sessMap[bsid] = { times: [], ua: null };
      if (e.time != null && !isNaN(e.time)) sessMap[bsid].times.push(e.time);
      if (e.type === 'session_start' && e.ua && !sessMap[bsid].ua) sessMap[bsid].ua = e.ua;
    }

    const sids = Object.keys(sessMap).filter(function(s) { return sessMap[s].times.length; });

    // Which bsids actually answered questions (used to filter interleaving false-positives)
    const answerBsids = new Set();
    for (const e of events) {
      if (e.type === 'answer' && e.bsid) answerBsids.add(e.bsid);
    }

    // 1. Platform change between sessions — show each browser/OS with the time it first appeared
    const platformBySid = {};
    for (const sid of sids) {
      if (sessMap[sid].ua) {
        platformBySid[sid] = uaFamily(sessMap[sid].ua);
      }
    }
    const uniquePlatforms = Array.from(new Set(Object.values(platformBySid)));
    if (uniquePlatforms.length > 1) {
      const detail = sids.filter(function(s) { return platformBySid[s]; }).map(function(s) {
        return platformBySid[s] + ' (from ' + fmtElapsed(minOf(sessMap[s].times)) + ')';
      });
      // Red only if multiple platforms answered questions; yellow if only one did (could be device switch).
      const platformsWithAnswers = new Set(
        sids.filter(function(s) { return platformBySid[s] && answerBsids.has(s); })
            .map(function(s) { return platformBySid[s]; })
      );
      flags.push({ level: platformsWithAnswers.size > 1 ? 'red' : 'yellow',
        msg: 'browser/OS changed across sessions: ' + detail.join(', ') });
    }

    // Overlaps/interleaving shorter than this are treated as transient (page refresh / crash recovery).
    const OVERLAP_RED_SEC = 60;

    // 2. Collect overlap data (merged with interleaving flag below)
    let overlapData = null;
    outer: for (let i = 0; i < sids.length; i++) {
      for (let j = i + 1; j < sids.length; j++) {
        const a = sessMap[sids[i]], b = sessMap[sids[j]];
        const aMin = minOf(a.times), aMax = maxOf(a.times);
        const bMin = minOf(b.times), bMax = maxOf(b.times);
        if (aMin <= bMax && bMin <= aMax) {
          const ovStart = Math.max(aMin, bMin), ovEnd = Math.min(aMax, bMax);
          overlapData = { ovStart, ovEnd, ovDuration: ovEnd - ovStart };
          break outer;
        }
      }
    }

    // 3. Interleaving: a session re-appears after a different session has taken over (A→B→A).
    // Only meaningful when the interloper actually answered questions.
    const ordered = events
      .filter(function(e) { return e.bsid && e.time != null && !isNaN(e.time); })
      .sort(function(a, b) { return a.time - b.time; });

    const firstSeen = {};
    const seenSids = new Set();
    let lastBsid = null;
    let interleaveRaw = null;
    for (const e of ordered) {
      if (!(e.bsid in firstSeen)) firstSeen[e.bsid] = e.time;
      if (e.bsid !== lastBsid) {
        if (seenSids.has(e.bsid)) {
          interleaveRaw = { firstAt: firstSeen[e.bsid], resumedAt: e.time, returningSid: e.bsid };
          break;
        }
        seenSids.add(e.bsid);
        lastBsid = e.bsid;
      }
    }

    let interleaveData = null;
    if (interleaveRaw) {
      const gapDuration = interleaveRaw.resumedAt - interleaveRaw.firstAt;
      const interloperHasAnswers = Object.keys(firstSeen).some(function(s) {
        return s !== interleaveRaw.returningSid &&
               firstSeen[s] > interleaveRaw.firstAt &&
               firstSeen[s] <= interleaveRaw.resumedAt &&
               answerBsids.has(s);
      });
      if (interloperHasAnswers) interleaveData = { firstAt: interleaveRaw.firstAt, resumedAt: interleaveRaw.resumedAt, gapDuration };
    }

    // Interleaving subsumes the overlap signal — emit one combined flag
    if (interleaveData) {
      if (interleaveData.gapDuration >= OVERLAP_RED_SEC) {
        let msg = 'multiple sessions actively answered questions simultaneously';
        if (overlapData) msg += ' (overlap ' + fmtElapsed(overlapData.ovStart) + '–' + fmtElapsed(overlapData.ovEnd) + ' elapsed)';
        msg += '; original session (from ' + fmtElapsed(interleaveData.firstAt) + ') resumed at ' + fmtElapsed(interleaveData.resumedAt);
        flags.push({ level: 'red', msg });
      } else {
        flags.push({ level: 'yellow',
          msg: 'brief session transition at ' + fmtElapsed(interleaveData.firstAt) +
               ' (resumed ' + fmtElapsed(interleaveData.resumedAt) + ') — likely page refresh or crash recovery' });
      }
    } else if (overlapData) {
      if (overlapData.ovDuration >= OVERLAP_RED_SEC) {
        flags.push({ level: 'red',
          msg: 'two sessions active at the same time (overlap ' +
               fmtElapsed(overlapData.ovStart) + '–' + fmtElapsed(overlapData.ovEnd) + ' elapsed)' });
      } else {
        const rangeStr = overlapData.ovDuration > 0
          ? fmtElapsed(overlapData.ovStart) + '–' + fmtElapsed(overlapData.ovEnd)
          : fmtElapsed(overlapData.ovStart);
        flags.push({ level: 'yellow',
          msg: 'brief session boundary overlap at ' + rangeStr + ' — likely page refresh or crash recovery' });
      }
    }

    return flags;
  }

  // ════════════════════════════════════════════════════════════════════════
  //  STATS
  // ════════════════════════════════════════════════════════════════════════
  function parseUA(ua) {
    if (!ua) return 'Unknown';
    // Simplified OS + browser extraction
    let os = 'Unknown OS';
    if      (/Windows NT 10/i.test(ua)) os = 'Win10';
    else if (/Windows NT 6\.3/i.test(ua)) os = 'Win8.1';
    else if (/Windows/i.test(ua)) os = 'Windows';
    else if (/iPhone|iPad|iPod/i.test(ua)) os = 'iOS';
    else if (/Mac OS X/i.test(ua)) os = 'macOS';
    else if (/Linux/i.test(ua)) os = 'Linux';
    else if (/Android/i.test(ua)) os = 'Android';

    // Underlying browser + major version. The Canvas Lockdown Browser (CLDB) token is a
    // wrapper around Chrome; Canvas reports the real engine, so we ignore CLDB and read
    // the Chrome/Firefox/etc. version beneath it.
    let br = 'Unknown', ver = '', m;
    if      (m = ua.match(/Edg\/(\d+)/i))                 { br = 'Edge';    ver = m[1]; }
    else if (m = ua.match(/Firefox\/(\d+)/i))             { br = 'Firefox'; ver = m[1]; }
    else if (m = ua.match(/Chrome\/(\d+)/i))              { br = 'Chrome';  ver = m[1]; }
    else if (m = ua.match(/Version\/(\d+)[\d.]*\s+Safari/i)) { br = 'Safari'; ver = m[1]; }
    else if (/Safari/i.test(ua))                          { br = 'Safari'; }

    return br + (ver ? ' ' + ver : '') + ' / ' + os;
  }

  // Browser+OS "family" without version — used for change detection so a benign version
  // bump (e.g. Chrome 129 → 130) doesn't get mistaken for a genuine browser switch.
  function uaFamily(ua) {
    return parseUA(ua).replace(/ \d+ \//, ' /');
  }

  function parseUAFull(ua) {
    if (!ua) return { browser: '—', os: '—' };
    var br = 'Unknown', os = 'Unknown', m;
    if      ((m = ua.match(/Edg(?:e)?\/(\d[\d.]*)/i)))            br = 'Edge ' + m[1];
    else if ((m = ua.match(/Firefox\/(\d[\d.]*)/i)))              br = 'Firefox ' + m[1];
    else if ((m = ua.match(/Chrome\/(\d[\d.]*)/i)))               br = 'Chrome ' + m[1];
    else if ((m = ua.match(/Version\/([\d.]+)[\s\S]*?Safari/i)))  br = 'Safari ' + m[1];
    else if (/Safari/i.test(ua))                                   br = 'Safari';
    var is64 = /Win64|x64|WOW64|x86_64/i.test(ua);
    var bit  = is64 ? ' 64-bit' : '';
    if (/iPhone|iPad|iPod/i.test(ua)) {
      m = ua.match(/OS ([\d_]+)/); os = 'iOS ' + (m ? m[1].replace(/_/g, '.') : '');
    } else if (/Windows NT/i.test(ua)) {
      m = ua.match(/Windows NT ([\d.]+)/);
      var wmap = { '10.0': '10', '11.0': '11', '6.3': '8.1', '6.2': '8', '6.1': '7', '6.0': 'Vista' };
      os = 'Windows ' + (m && wmap[m[1]] ? wmap[m[1]] : m ? m[1] : '') + bit;
    } else if (/Mac OS X/i.test(ua)) {
      m = ua.match(/Mac OS X ([\d_]+)/);
      var macBit = /Intel Mac OS X/i.test(ua) ? ' 64-bit' : bit;
      os = 'OS X ' + (m ? m[1].replace(/_/g, '.') : '') + macBit;
    } else if (/Android/i.test(ua)) {
      m = ua.match(/Android ([\d.]+)/); os = 'Android ' + (m ? m[1] : '');
    } else if (/Linux/i.test(ua)) {
      os = 'Linux' + bit;
    }
    return { browser: br, os: os };
  }

  function computeStats(sessionIds, rawEvents, sessionInfos) {
    const { events, userAgents, startUserAgents, browserSessions } = parseApiEvents(rawEvents);
    const attemptCount   = sessionIds.length;  // distinct Canvas quiz attempts (from fiber)
    const sessionCount   = browserSessions.length || attemptCount; // unique browser session IDs = real "sessions"

    // Duration from participant_session timestamps (accurate: covers review time after last answer)
    var durationSec = null;
    var submittedAt = null;
    if (sessionInfos && sessionInfos.length) {
      var withStart  = sessionInfos.filter(function(s) { return s.createdAt; });
      var withSubmit = sessionInfos.filter(function(s) { return s.submittedAt; });
      if (withStart.length && withSubmit.length) {
        var earliest = withStart.reduce(function(a, b) {
          return new Date(a.createdAt) < new Date(b.createdAt) ? a : b;
        });
        var latest = withSubmit.reduce(function(a, b) {
          return new Date(a.submittedAt) > new Date(b.submittedAt) ? a : b;
        });
        durationSec = Math.round((new Date(latest.submittedAt) - new Date(earliest.createdAt)) / 1000);
        submittedAt = latest.submittedAt;
      }
    }

    // First-answer time per unique question (count all answered items; time may be null for burst only)
    const firstAnswerTime = {};
    for (const e of events) {
      if (e.type !== 'answer' || e.q == null) continue;
      if (!(e.q in firstAnswerTime)) firstAnswerTime[e.q] = e.time; // time may be null
    }

    const timed = events.filter(e => e.time !== null);

    const awayCount = events.filter(e => e.type === 'away').length;

    // Count session start/resume events from the event log.
    // SESSION_STARTED_OR_RESUMED_EVENT fires for both new sessions AND resumes within
    // the same session ID (browser crash, refresh, tab re-open). If start events exceed
    // the number of session IDs, the extra ones are resumes.
    const startEventCount = events.filter(e => e.type === 'session_start').length;
    const resumeCount = Math.max(0, startEventCount - sessionCount);

    // Rapid-burst: sliding window over first-answer timeline
    const timeline = Object.keys(firstAnswerTime)
      .map(q => ({ q, t: firstAnswerTime[q] }))
      .sort((a, b) => a.t - b.t);

    let maxBurst = 0, burstExample = null;
    for (let i = 0; i < timeline.length; i++) {
      const win = timeline.filter(e => e.t >= timeline[i].t && e.t <= timeline[i].t + BURST_SEC);
      if (win.length > maxBurst) { maxBurst = win.length; burstExample = win; }
    }

    // Inactivity gaps across all events
    const sortedTimed = timed.slice().sort((a, b) => a.time - b.time);
    const gaps = [];
    for (let i = 1; i < sortedTimed.length; i++) {
      const gapMin = (sortedTimed[i].time - sortedTimed[i - 1].time) / 60;
      if (gapMin > GAP_MIN) gaps.push(gapMin.toFixed(0) + ' min');
    }

    // Browser/OS display: use ONLY the user agents reported in SESSION_STARTED events
    // (the genuine browser). RESPONSE events during a locked-down quiz carry a CLDB-wrapped
    // user agent that never appears in the Canvas log, so we exclude those here.
    const uaForDisplay = startUserAgents.length ? startUserAgents : userAgents;
    const browserSigs = uaForDisplay.map(parseUA);
    const uniqueBrowsers = Array.from(new Set(browserSigs));

    const flags = [];

    // Session anomaly detection: only flag specific misconduct patterns.
    // Multiple session IDs alone (e.g. page refresh) is NOT flagged.
    const sessionAnomalyFlags = detectSessionAnomalies(events, browserSessions);
    for (const f of sessionAnomalyFlags) flags.push(f);

    // Fallback: multiple Canvas attempts with no browser-session detail
    if (sessionAnomalyFlags.length === 0 && attemptCount > 1 && sessionCount <= 1) {
      flags.push({ level: 'red', msg: attemptCount + ' separate quiz attempts' });
    }

    if (maxBurst >= BURST_COUNT_RED) flags.push({
      level: 'red',
      msg: 'Rapid burst: ' + maxBurst + ' Qs in ' + BURST_SEC + 's (' +
           burstExample.map(e => 'Q' + e.q).join(', ') + ')'
    });
    else if (maxBurst >= BURST_COUNT_YELLOW) flags.push({
      level: 'yellow',
      msg: 'Rapid burst: ' + maxBurst + ' Qs in ' + BURST_SEC + 's (' +
           burstExample.map(e => 'Q' + e.q).join(', ') + ')'
    });

    if (gaps.length) {
      flags.push({ level: 'yellow', msg: 'Inactivity gap(s): ' + gaps.join(', ') });
    }

    // (multi-browser UA flag suppressed — already covered by browser session count above)

    const flagLevel = flags.some(f => f.level === 'red')    ? 'red'
                    : flags.some(f => f.level === 'yellow') ? 'yellow'
                    : 'green';

    return {
      sessionCount, resumeCount, durationSec,
      totalQuestions: Object.keys(firstAnswerTime).length,
      maxBurst, burstExample, awayCount,
      uniqueBrowsers, browserSessions: browserSessions.length,
      flags, flagLevel,
      parsedEvents: events,
      submittedAt,
    };
  }

  // ════════════════════════════════════════════════════════════════════════
  //  REPORT
  // ════════════════════════════════════════════════════════════════════════
  function fmtDur(s) {
    if (s === null || s === undefined) return '—';
    return Math.floor(s / 60) + 'm ' + (s % 60) + 's';
  }

  // ════════════════════════════════════════════════════════════════════════
  //  PDF EXPORT
  // ════════════════════════════════════════════════════════════════════════
  const BSID_PALETTE = [
    null,       // first session — plain white
    '#fff8e1',  // amber
    '#e3f2fd',  // sky blue
    '#f3e5f5',  // lavender
    '#e8f5e9',  // mint
    '#fce4ec',  // rose
  ];

  function buildStudentPdfHtml(studentsArr) {
    function pdfFmtScore(r) {
      if (r.score == null) return '—';
      var pct = r.percentage != null ? r.percentage : (r.pointsPossible ? r.score / r.pointsPossible : null);
      var raw = r.pointsPossible != null ? r.score + '/' + r.pointsPossible : String(r.score);
      return (pct != null ? Math.round(pct * 100) + '% · ' : '') + raw;
    }
    function pdfFmtElapsed(sec) {
      if (sec == null || isNaN(sec)) return '?:??';
      var s = Math.max(0, Math.round(sec));
      var h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), ss = s % 60;
      var p = function(n) { return n < 10 ? '0' + n : '' + n; };
      return h > 0 ? h + ':' + p(m) + ':' + p(ss) : m + ':' + p(ss);
    }
    var _fmtDbg = false;
    function fmtAnswerVal(val) {
      if (val == null) return null;
      if (typeof val === 'string') {
        // Bare UUID string in array — brute-force scan all items for matching choice
        if (/^[0-9a-f-]{36}$/i.test(val) && itemMap) {
          for (var _sk in itemMap) { if (itemMap[_sk].choices[val]) return itemMap[_sk].choices[val]; }
        }
        return val || null;
      }
      if (typeof val === 'number' || typeof val === 'boolean') return String(val);
      if (Array.isArray(val)) {
        // Canvas answer format: array of {id: itemId, value: choiceId, type: "..."}
        var parts = val.map(function(v) {
          if (!v || typeof v !== 'object') return fmtAnswerVal(v);
          var choiceId = typeof v.value === 'string' ? v.value : null;
          // item.item.id can be an integer (MCSS) or UUID string (fill-in-blank)
          var itemId = typeof v.id === 'string' ? v.id
                     : typeof v.id === 'number' ? String(v.id)
                     : null;
          // Primary lookup: direct item→choice match
          if (itemMap && itemId && choiceId && itemMap[itemId] && itemMap[itemId].choices[choiceId]) {
            return itemMap[itemId].choices[choiceId];
          }
          // Fallback: brute-force scan all items (covers integer-id MCSS questions)
          if (itemMap && choiceId && /^[0-9a-f-]{36}$/i.test(choiceId)) {
            for (var _bk in itemMap) { if (itemMap[_bk].choices[choiceId]) return itemMap[_bk].choices[choiceId]; }
          }
          // Debug first still-unresolved UUID
          if (!_fmtDbg && choiceId && /^[0-9a-f-]{36}$/i.test(choiceId)) {
            _fmtDbg = true;
            console.log('[quiz] fmtAnswerVal still-unresolved — v.id:', v.id, '(type:', typeof v.id, ')',
              '| choiceId:', choiceId,
              '| mapKeys (first 8):', itemMap ? Object.keys(itemMap).slice(0, 8).join(', ') : 'null');
          }
          // Final fallback: for text/essay the value IS the student's text
          return choiceId || fmtAnswerVal(v.value) || null;
        }).filter(Boolean);
        return parts.join('<br>') || null;
      }
      if (typeof val === 'object') {
        var ks = Object.keys(val);
        if (!ks.length) return null;
        if (ks.length === 1 && !ks[0].match(/^blank[_\s]?\d+$/i)) return fmtAnswerVal(val[ks[0]]);
        var parts2 = ks.map(function(k) {
          var m2 = k.match(/blank[_\s]?(\d+)/i);
          return (m2 ? 'Blank ' + (parseInt(m2[1], 10) + 1) : k) + ': ' + (fmtAnswerVal(val[k]) || '');
        });
        return parts2.join('<br>') || null;
      }
      return JSON.stringify(val);
    }

    var css = [
      '* { box-sizing:border-box; margin:0; padding:0; }',
      'body { font-family:Arial,Helvetica,sans-serif; font-size:13px; color:#1a1a1a; padding:24px; max-width:960px; margin:0 auto; }',
      '.student-block { margin-bottom:48px; }',
      '.page-break { break-after:page; }',
      '.s-header { display:flex; justify-content:space-between; align-items:flex-start; border-bottom:2px solid #003e6b; padding-bottom:12px; margin-bottom:14px; }',
      '.s-name { font-size:20px; font-weight:bold; color:#003e6b; margin-bottom:5px; }',
      '.s-meta { color:#555; font-size:12px; line-height:1.6; }',
      '.flags-box { padding:10px 14px; border-radius:4px; margin-bottom:14px; font-size:12px; line-height:1.9; }',
      '.flags-label { font-weight:bold; font-size:13px; margin-bottom:3px; }',
      '.flag-red { color:#b71c1c; }',
      '.flag-yellow { color:#e65100; }',
      '.flag-green { color:#2e7d32; }',
      '.legend { display:flex; gap:18px; font-size:11px; color:#555; margin-bottom:12px; flex-wrap:wrap; align-items:center; }',
      '.legend-item { display:flex; align-items:center; gap:5px; }',
      '.legend-sw { width:13px; height:13px; border:1px solid #bbb; border-radius:2px; flex-shrink:0; }',
      'table.log { width:100%; border-collapse:collapse; }',
      'table.log tr { border-bottom:1px solid #e0e0e0; }',
      '.ev-time { font-family:monospace; font-size:14px; font-weight:600; color:#333; padding:11px 12px 11px 0; white-space:nowrap; width:62px; vertical-align:top; border-right:1px solid #ddd; }',
      '.ev-body { padding:11px 0 11px 16px; vertical-align:top; }',
      '.ev-label { font-size:13px; font-weight:600; }',
      'table.attrs { border-collapse:collapse; margin-top:7px; font-size:11px; }',
      'table.attrs td { padding:2px 14px 2px 0; vertical-align:top; }',
      'table.attrs td:first-child { color:#777; white-space:nowrap; min-width:130px; }',
      'table.attrs td:last-child { font-family:monospace; font-size:11px; color:#333; word-break:break-all; }',
      '.no-print { text-align:center; margin:32px 0; }',
      '.print-btn { padding:11px 30px; background:#003e6b; color:#fff; border:none; border-radius:5px; font-size:14px; cursor:pointer; }',
      '@media print {',
      '  .no-print { display:none !important; }',
      '  body { padding:0; font-size:11px; }',
      '  .student-block { padding:8mm 12mm; }',
      '  .ev-time { font-size:11px; }',
      '  .ev-label { font-size:11px; }',
      '  table.attrs td { font-size:10px; }',
      '}'
    ].join('\n');

    var blocks = studentsArr.map(function(r, rIdx) {
      var bsidOrder = [], bsidCounter = 0;
      function bsidColor(bsid) {
        if (!bsid) return null;
        var idx = bsidOrder.indexOf(bsid);
        if (idx === -1) { bsidOrder.push(bsid); idx = bsidCounter++; }
        return BSID_PALETTE[idx % BSID_PALETTE.length];
      }

      // Find absolute start time for computing synthetic submission elapsed
      var startAbs = null;
      for (var ei = 0; ei < (r.parsedEvents || []).length; ei++) {
        if (r.parsedEvents[ei].abs != null) { startAbs = r.parsedEvents[ei].abs; break; }
      }
      var hasSubmitEvent = (r.parsedEvents || []).some(function(e) { return e.type === 'session_submit'; });
      var syntheticSubmitElapsed = null;
      if (!hasSubmitEvent && r.submittedAt && startAbs != null) {
        var submitMs = new Date(r.submittedAt).getTime();
        if (submitMs > startAbs) syntheticSubmitElapsed = Math.round((submitMs - startAbs) / 1000);
      }

      // Build event rows -- no summarization, every event shown as-is
      var lastBsid = null;
      var rowsHtml = (r.parsedEvents || []).map(function(e) {
        if (e.bsid) lastBsid = e.bsid;
        var color = bsidColor(e.bsid);
        var rowBg = color ? 'background:' + color + ';' : '';
        var label = '', attrRows = '';

        if (e.type === 'session_start') {
          label = 'Session started';
          var uaFull = parseUAFull(e.ua);
          attrRows =
            '<tr><td>Browser session ID</td><td>' + (e.bsid || '—') + '</td></tr>' +
            '<tr><td>Browser</td><td>' + uaFull.browser + '</td></tr>' +
            '<tr><td>Operating System</td><td>' + uaFull.os + '</td></tr>' +
            (e.ip ? '<tr><td>IP Address</td><td>' + e.ip + '</td></tr>' : '');
        } else if (e.type === 'answer') {
          label = 'Answered question ' + e.q;
          var aDisp = fmtAnswerVal(e.answerVal);
          if (aDisp) attrRows = '<tr><td>Answer value</td><td>' + aDisp + '</td></tr>';
        } else if (e.type === 'away') {
          label = 'Stopped viewing quiz-taking page';
        } else if (e.type === 'focused') {
          label = 'Resumed viewing quiz-taking page';
        } else if (e.type === 'session_submit') {
          label = 'Quiz submitted';
        } else {
          return '';
        }

        return '<tr style="' + rowBg + '">' +
          '<td class="ev-time">' + pdfFmtElapsed(e.time) + '</td>' +
          '<td class="ev-body">' +
            '<div class="ev-label">' + label + '</div>' +
            (attrRows ? '<table class="attrs"><tbody>' + attrRows + '</tbody></table>' : '') +
          '</td>' +
        '</tr>';
      }).join('');

      // Synthetic submission row when roster has submittedAt but no submit event in the log
      if (syntheticSubmitElapsed != null) {
        var submitColor = bsidColor(lastBsid);
        var submitBg = submitColor ? 'background:' + submitColor + ';' : '';
        rowsHtml += '<tr style="' + submitBg + '">' +
          '<td class="ev-time">' + pdfFmtElapsed(syntheticSubmitElapsed) + '</td>' +
          '<td class="ev-body"><div class="ev-label">Quiz submitted</div></td>' +
          '</tr>';
      }

      // Session legend -- full BSID so instructor can cross-reference Canvas
      var legendHtml = bsidOrder.map(function(bsid, idx) {
        var c = BSID_PALETTE[idx % BSID_PALETTE.length] || '#fff';
        return '<div class="legend-item">' +
          '<div class="legend-sw" style="background:' + (c || '#fff') + '"></div>' +
          '<span>Session ' + (idx + 1) + ': ' + bsid + '</span>' +
          '</div>';
      }).join('');

      var flagBg     = r.flagLevel === 'red'    ? '#fdecea' : r.flagLevel === 'yellow' ? '#fff8e1' : '#e8f5e9';
      var flagBorder = r.flagLevel === 'red'    ? '#e57373' : r.flagLevel === 'yellow' ? '#ffb74d' : '#81c784';
      var flagsContent = (r.flags || []).length
        ? (r.flags || []).map(function(f) { return '<div class="flag-' + f.level + '">▸ ' + f.msg + '</div>'; }).join('')
        : '<div class="flag-green">No anomalies detected</div>';

      var isLast = rIdx === studentsArr.length - 1;

      return '<div class="student-block' + (!isLast ? ' page-break' : '') + '">' +
        '<div class="s-header">' +
          '<div>' +
            '<div class="s-name">' + r.name + '</div>' +
            '<div class="s-meta">Score: ' + pdfFmtScore(r) + ' · Duration: ' + fmtDur(r.durationSec) + ' · Browser Sessions: ' + (r.sessionCount || '—') + '</div>' +
            '<div class="s-meta">' + (r.uniqueBrowsers || []).join(' · ') + '</div>' +
          '</div>' +
          '<div class="s-meta" style="text-align:right">Quiz Session Log' +
            (quizTitle ? '<br>' + quizTitle : '') +
            '<br>Generated: ' + new Date().toLocaleString() + '</div>' +
        '</div>' +
        '<div class="flags-box" style="background:' + flagBg + ';border-left:4px solid ' + flagBorder + '">' +
          '<div class="flags-label">Anomaly Flags</div>' + flagsContent +
        '</div>' +
        (legendHtml ? '<div class="legend"><b style="font-size:11px;color:#444">Sessions:</b> ' + legendHtml + '</div>' : '') +
        '<table class="log"><tbody>' + rowsHtml + '</tbody></table>' +
      '</div>';
    }).join('');

    return '<!DOCTYPE html><html><head><meta charset="utf-8">' +
      '<title>' + (quizTitle ? quizTitle + ' - ' : '') + 'Quiz Session Log</title>' +
      '<style>' + css + '</style></head>' +
      '<body>' + blocks +
      '<div class="no-print"><button class="print-btn" onclick="window.print()">🖨 Print / Save as PDF</button></div>' +
      '</body></html>';
  }

    function openStudentPdf(result) {
    var html = buildStudentPdfHtml([result]);
    var w = window.open('', '_blank');
    if (!w) { alert('Pop-up blocked — allow pop-ups for this site and try again.'); return; }
    w.document.write(html);
    w.document.close();
  }

  function openBulkPdf(results) {
    var flagged = results.filter(function(r) { return r.flagLevel === 'red' || r.flagLevel === 'yellow'; });
    if (!flagged.length) { alert('No flagged students to export.'); return; }
    var html = buildStudentPdfHtml(flagged);
    var w = window.open('', '_blank');
    if (!w) { alert('Pop-up blocked — allow pop-ups for this site and try again.'); return; }
    w.document.write(html);
    w.document.close();
  }

  function showReport(results, totalStudents) {
    const ORDER  = { red: 0, yellow: 1, green: 2, error: 3 };
    const BG     = { red: '#fdecea', yellow: '#fff8e1', green: '#e8f5e9', error: '#f5f5f5' };
    const BORDER = { red: '#e57373', yellow: '#ffb74d', green: '#81c784', error: '#bbb' };
    const ICON   = { red: '🔴', yellow: '🟡', green: '🟢', error: '⚠️' };

    // The roster is fetched from the quiz-lti participants endpoint, which delivers students
    // in Canvas sortable_name ("Last, First") order — the authoritative surname ordering that
    // correctly handles compound surnames ("Abdel Naby"). Capture that delivered index now,
    // before any re-sort, and use it as the canonical "by last name" sort.
    results.forEach((r, i) => { if (r._rosterIdx == null) r._rosterIdx = i; });

    // PDF lookup map — keyed by name so per-row buttons survive re-sorts
    window.__nqPdfMap__ = {};
    results.forEach(r => { if (r.name) window.__nqPdfMap__[r.name] = r; });

    // ── Score + name helpers ──
    function scorePct(r) {
      if (r.percentage != null) return r.percentage;
      if (r.score != null && r.pointsPossible) return r.score / r.pointsPossible;
      return null;
    }
    function fmtScore(r) {
      if (r.score == null) return '—';
      const pct = scorePct(r);
      const raw = r.pointsPossible != null ? (r.score + '/' + r.pointsPossible) : String(r.score);
      return (pct != null ? Math.round(pct * 100) + '% · ' : '') + raw;
    }
    function lastName(n) {
      const parts = String(n || '').trim().split(/\s+/);
      return (parts[parts.length - 1] || '').toLowerCase();
    }

    // ── Sortable columns (comparators return ascending order) ──
    const SORTERS = {
      name:     (a, b) => (a._rosterIdx != null && b._rosterIdx != null)
                            ? a._rosterIdx - b._rosterIdx
                            : lastName(a.name).localeCompare(lastName(b.name)),
      sessions: (a, b) => (a.sessionCount || 0) - (b.sessionCount || 0),
      duration: (a, b) => (a.durationSec || 0) - (b.durationSec || 0),
      score:    (a, b) => (scorePct(a) == null ? -1 : scorePct(a)) - (scorePct(b) == null ? -1 : scorePct(b)),
      burst:    (a, b) => (a.maxBurst || 0) - (b.maxBurst || 0),
      flags:    (a, b) => (ORDER[a.flagLevel] != null ? ORDER[a.flagLevel] : 3) - (ORDER[b.flagLevel] != null ? ORDER[b.flagLevel] : 3),
    };
    let sortKey = 'flags', sortDir = 1; // flags ascending = red first
    function applySort() {
      const cmp = SORTERS[sortKey] || SORTERS.flags;
      results.sort((a, b) => {
        if (a.error && !b.error) return 1;   // error rows always sink to the bottom
        if (b.error && !a.error) return -1;
        if (a.error && b.error) return 0;
        return cmp(a, b) * sortDir;
      });
    }
    applySort();

    // ── CSV (rebuilt at download time so it matches the current sort) ──
    function csvCell(x) { return '"' + String(x == null ? '' : x).replace(/"/g, '""') + '"'; }
    function buildCsv() {
      const rows = [['Student', 'Browser Sessions', 'Duration', 'Score',
                     'Max Burst (' + BURST_SEC + 's)', 'Browser / OS', 'Flags'].join(',')];
      for (const r of results) {
        if (r.error) { rows.push([r.name, 'ERROR', '', '', '', '', r.error].map(csvCell).join(',')); continue; }
        rows.push([
          r.name, r.sessionCount, fmtDur(r.durationSec), fmtScore(r).replace(' · ', ' '),
          r.maxBurst || 0, (r.uniqueBrowsers || []).join(' | '),
          (r.flags || []).map(x => x.msg).join(' | ')
        ].map(csvCell).join(','));
      }
      return rows.join('\n');
    }

    // ── Per-row rendering (called again on every re-sort) ──
    function rowHtml(r) {
      const lv  = r.flagLevel || 'error';
      const bg  = BG[lv], bdr = BORDER[lv], ico = ICON[lv];

      if (r.error) return '<tr style="background:' + bg + ';border-left:4px solid ' + bdr + '">' +
        '<td colspan="7" style="padding:8px 12px;font-size:12px;color:#c00">' +
        ico + ' <b>' + r.name + '</b> — ' + r.error + '</td></tr>';

      const flagHtml = (r.flags || []).length
        ? r.flags.map(fl =>
            '<div style="font-size:11px;color:' + (fl.level === 'red' ? '#b71c1c' : '#e65100') +
            ';margin-top:3px">▸ ' + fl.msg + '</div>'
          ).join('')
        : '<span style="color:#888;font-size:11px">No flags</span>';

      const browsersHtml = (r.uniqueBrowsers || []).length > 1
        ? '<span style="color:#e65100">' + r.uniqueBrowsers.join('<br>') + '</span>'
        : (r.uniqueBrowsers || []).join('') || '—';

      return '<tr style="background:' + bg + ';border-left:4px solid ' + bdr +
             ';border-bottom:1px solid rgba(0,0,0,.06)">' +
        '<td style="padding:9px 12px;font-weight:600;font-size:13px">' + ico + ' ' + r.name + '</td>' +
        '<td style="padding:9px 8px;text-align:center;font-size:13px">' +
          (r.sessionCount > 1 && r.flagLevel === 'red'
            ? '<b style="color:#b71c1c">' + r.sessionCount + '</b>'
            : r.sessionCount > 1
              ? '<span style="color:#888">' + r.sessionCount + '</span>'
              : r.sessionCount) +
        '</td>' +
        '<td style="padding:9px 8px;font-size:13px">' + fmtDur(r.durationSec) + '</td>' +
        '<td style="padding:9px 8px;text-align:center;font-size:13px;white-space:nowrap">' + fmtScore(r) + '</td>' +
        '<td style="padding:9px 8px;text-align:center;font-size:13px">' +
          (r.maxBurst >= BURST_COUNT_RED
            ? '<b style="color:#b71c1c">' + r.maxBurst + '</b>'
            : r.maxBurst >= BURST_COUNT_YELLOW
              ? '<span style="color:#e65100">' + r.maxBurst + '</span>'
              : (r.maxBurst || '—')) +
        '</td>' +
        '<td style="padding:9px 8px;font-size:12px;line-height:1.5">' + browsersHtml + '</td>' +
        '<td style="padding:9px 12px">' + flagHtml +
          (r.parsedEvents && r.parsedEvents.length
            ? '<div style="margin-top:6px"><button class="__nq_pdf_btn__" data-name="' +
              encodeURIComponent(r.name) +
              '" style="font-size:11px;padding:3px 9px;cursor:pointer;background:#003e6b;' +
              'color:#fff;border:none;border-radius:3px">📄 Log PDF</button></div>'
            : '') +
        '</td>' +
        '</tr>';
    }
    function bodyHtml() { return results.map(rowHtml).join(''); }

    // ── Sortable header cell ──
    function th(label, key, opts) {
      opts = opts || {};
      const align = opts.center ? 'text-align:center;' : '';
      const tip = opts.title ? ' title="' + opts.title + '"' : '';
      if (!key) return '<th style="padding:10px 8px;' + align + '"' + tip + '>' + label + '</th>';
      return '<th data-sort="' + key + '" style="padding:10px 8px;' + align +
             'cursor:pointer;user-select:none"' + tip + '>' + label +
             ' <span class="__nq_ind" data-for="' + key + '" style="opacity:.35;font-size:10px">⇅</span></th>';
    }

    const redCount    = results.filter(r => r.flagLevel === 'red').length;
    const yellowCount = results.filter(r => r.flagLevel === 'yellow').length;
    const greenCount  = results.filter(r => r.flagLevel === 'green').length;

    const modal = document.createElement('div');
    modal.id = '__nq_report__';
    modal.style.cssText = [
      'position:fixed;inset:0;background:rgba(0,0,0,.55)',
      'z-index:99999;display:flex;align-items:flex-start',
      'justify-content:center;overflow-y:auto;padding:32px 16px',
      'font-family:sans-serif'
    ].join(';');

    modal.innerHTML =
      '<div style="background:#fff;border-radius:10px;width:100%;max-width:1100px;' +
           'box-shadow:0 8px 40px rgba(0,0,0,.35);margin:auto">' +

        '<div style="background:#003e6b;color:#fff;padding:16px 24px;border-radius:10px 10px 0 0;' +
             'display:flex;justify-content:space-between;align-items:center">' +
          '<div>' +
            '<div style="font-size:11px;opacity:.65;margin-bottom:3px">New Quizzes — Anomaly Analysis</div>' +
            '<div style="font-size:19px;font-weight:bold">Session Log Report</div>' +
          '</div>' +
          '<button id="__nq_rclose__" style="background:rgba(255,255,255,.15);border:none;' +
            'color:#fff;padding:7px 16px;border-radius:4px;cursor:pointer;font-size:13px">' +
            '✕ Close</button>' +
        '</div>' +

        '<div style="padding:14px 24px;background:#f0f4f8;border-bottom:1px solid #ddd;' +
             'display:flex;gap:24px;align-items:center;flex-wrap:wrap;font-size:13px">' +
          '<span><b>' + results.length + '</b> of <b>' + totalStudents + '</b> students analysed' +
            (MAX_STUDENTS < 9999 ? ' <span style="color:#888">(limit: ' + MAX_STUDENTS + ')</span>' : '') +
          '</span>' +
          '<span>🔴 <b style="color:#b71c1c">' + redCount + '</b> high-priority</span>' +
          '<span>🟡 <b style="color:#e65100">' + yellowCount + '</b> review</span>' +
          '<span>🟢 <b style="color:#2e7d32">' + greenCount + '</b> clear</span>' +
          '<div style="margin-left:auto;display:flex;gap:8px;align-items:center">' +
            '<button id="__nq_pdfbulk__" style="padding:8px 18px;background:#5c6bc0;' +
              'color:#fff;border:none;border-radius:4px;cursor:pointer;font-size:13px;font-weight:600">' +
              '📄 Export Flagged PDFs</button>' +
            '<button id="__nq_csv__" style="padding:8px 18px;background:#003e6b;' +
              'color:#fff;border:none;border-radius:4px;cursor:pointer;font-size:13px;font-weight:600">' +
              '⬇ Download CSV</button>' +
          '</div>' +
        '</div>' +

        '<div style="overflow-x:auto">' +
          '<table style="width:100%;border-collapse:collapse;font-size:13px">' +
            '<thead><tr style="background:#e0e7ef;text-align:left">' +
              th('Student', 'name', { title: 'Sort by last name (Canvas sortable order)' }) +
              th('Browser Sessions', 'sessions', { center: true, title: 'Unique browser session IDs — each is a distinct browser instance' }) +
              th('Duration', 'duration') +
              th('Score', 'score', { center: true, title: 'Score kept (highest attempt)' }) +
              th('Burst', 'burst', { center: true, title: 'Max distinct questions answered in any ' + BURST_SEC + 's window' }) +
              th('Browser / OS', null) +
              th('Flags', 'flags', { title: 'Sort by severity (red → green)' }) +
            '</tr></thead>' +
            '<tbody id="__nq_tbody__">' + bodyHtml() + '</tbody>' +
          '</table>' +
        '</div>' +

        '<div style="padding:10px 24px;font-size:11px;color:#888;border-top:1px solid #eee">' +
          'Thresholds: burst ≥' + BURST_COUNT_YELLOW + ' Qs in ' + BURST_SEC + 's (red ≥' + BURST_COUNT_RED + ') · ' +
          'inactivity gap &gt;' + GAP_MIN + ' min · click a column header to sort' +
        '</div>' +
      '</div>';

    document.body.appendChild(modal);

    document.getElementById('__nq_rclose__').onclick = () => {
      const el = document.getElementById('__nq_report__');
      if (el) el.remove();
    };

    document.getElementById('__nq_csv__').onclick = () => {
      const blob = new Blob([buildCsv()], { type: 'text/csv;charset=utf-8;' });
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = 'quiz_anomaly_report_' + new Date().toISOString().slice(0, 10) + '.csv';
      a.click();
      URL.revokeObjectURL(a.href);
    };

    document.getElementById('__nq_pdfbulk__').onclick = () => openBulkPdf(results);

    modal.addEventListener('click', function(e) {
      const btn = e.target.closest && e.target.closest('.__nq_pdf_btn__');
      if (!btn) return;
      const name = decodeURIComponent(btn.dataset.name || '');
      const r = window.__nqPdfMap__ && window.__nqPdfMap__[name];
      if (r) openStudentPdf(r);
    });

    // ── Column sorting ──
    const DEFAULT_DIR = { name: 1, flags: 1, sessions: -1, duration: -1, score: -1, burst: -1 };
    function updateIndicators() {
      modal.querySelectorAll('.__nq_ind').forEach(el => {
        const k = el.getAttribute('data-for');
        if (k === sortKey) { el.textContent = sortDir === 1 ? '▲' : '▼'; el.style.opacity = '1'; }
        else { el.textContent = '⇅'; el.style.opacity = '.35'; }
      });
    }
    modal.querySelectorAll('th[data-sort]').forEach(thEl => {
      thEl.onclick = () => {
        const k = thEl.getAttribute('data-sort');
        if (k === sortKey) sortDir = -sortDir;                 // same column → toggle direction
        else { sortKey = k; sortDir = DEFAULT_DIR[k] || 1; }   // new column → sensible default
        applySort();
        document.getElementById('__nq_tbody__').innerHTML = bodyHtml();
        updateIndicators();
      };
    });
    updateIndicators();
  }

}

// ── Tampermonkey entry point (also works when pasted into the console) ───────
(function __nqInit() {
  console.log('[NQ] script loaded — host:', location.hostname, '| href:', location.href);
  if (document.getElementById('__nq_launch_btn__')) return;

  function injectButton() {
    console.log('[NQ] injecting button');
    const btn = document.createElement('button');
    btn.id = '__nq_launch_btn__';
    btn.textContent = '🔍 Anomaly Check';
    btn.style.cssText = [
      'position:fixed', 'bottom:24px', 'right:24px', 'z-index:99999',
      'padding:10px 20px', 'background:#003e6b', 'color:#fff',
      'border:none', 'border-radius:6px', 'font-size:14px', 'font-weight:600',
      'cursor:pointer', 'box-shadow:0 3px 12px rgba(0,0,0,.35)',
      'font-family:sans-serif', 'transition:background .15s',
    ].join(';');
    btn.onmouseover = () => { btn.style.background = '#005a9c'; };
    btn.onmouseout  = () => { btn.style.background = '#003e6b'; };
    btn.onclick = async () => {
      btn.disabled = true; btn.textContent = '⏳ Running…';
      try { await __nqRun(); }
      finally { btn.disabled = false; btn.textContent = '🔍 Anomaly Check'; }
    };
    document.body.appendChild(btn);
  }

  // Poll until the moderate-page student table appears (caps at ~24 s)
  function tryInject(n) {
    n = n || 0;
    if (n > 30) { console.log('[NQ] tryInject: gave up after 30 attempts'); return; }
    console.log('[NQ] tryInject attempt', n);
    if (document.querySelector('[data-automation="sdk-moderation-moderate-session-log-link"]')) {
      injectButton();
    } else {
      setTimeout(function() { tryInject(n + 1); }, 800);
    }
  }
  tryInject();
}());
